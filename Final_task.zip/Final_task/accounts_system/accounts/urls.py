# accounts/urls.py

from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('income/', views.income_form, name='income_form'),
    path('expense/', views.expense_form, name='expense_form'),
    path('reports/', views.report_view, name='report_view'),
]
