

from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required, user_passes_test
from .models import Company, Income, Expense
from .forms import IncomeForm, ExpenseForm

def index(request):
    return render(request, 'accounts/index.html')

@login_required
@user_passes_test(lambda u: u.groups.filter(name='Admin').exists())
def income_form(request):
    if request.method == 'POST':
        form = IncomeForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('index')
    else:
        form = IncomeForm()
    return render(request, 'accounts/income_form.html', {'form': form})

@login_required
def expense_form(request):
    if request.method == 'POST':
        form = ExpenseForm(request.POST)
        if form.is_valid():
            expense = form.save(commit=False)
            expense.submitted_by = request.user
            expense.save()
            return redirect('index')
    else:
        form = ExpenseForm()
    return render(request, 'accounts/expense_form.html', {'form': form})

@login_required
def report_view(request):
    if request.user.is_superuser:
        expenses = Expense.objects.all()
    else:
        company = Company.objects.get(owner=request.user)
        expenses = Expense.objects.filter(account__company=company)

    return render(request, 'accounts/report.html', {'expenses': expenses})
