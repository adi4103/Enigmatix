# accounts/admin.py

from django.contrib import admin
from .models import Company, Account, Income, Expense

admin.site.register(Company)
admin.site.register(Account)
admin.site.register(Income)
admin.site.register(Expense)
